# 💽 CMS ISO Information

- OS Version: Ubuntu 22.04 64-Bit
- Image Version: CMS V1.2
- Release Date: 05 May 2025
- File Size: 8.5GB
- Supported Devices: Dell OptiPlex, Addsoft Think Client

## 📥 Download
👉 [Click here to download ISO for Addsoft BA](http://182.19.28.206/05May25-ATPL-CMS-IMAGEV2-128GB-FIX-HWTime-FPClient.zip)

👉 [Click here to download ISO for Prakash Narshimha BA](http://182.19.28.206/cms_3.3.zip)
