# ☎️ CMS Helpline Numbers – CRIS Support

For **complaints, queries, or suggestions** regarding any CMS module,  
you can contact the CMS Support Team **24×7×365** (including all holidays).

---

### 📞 Helpline Numbers:
- 📱 **Mobile:** 7217709646  
- ☎️ **Landline:** (011) - 26886120  
- ☎️ **Landline:** (011) - 24674160

---

